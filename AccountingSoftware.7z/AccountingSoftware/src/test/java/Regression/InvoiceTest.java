package Regression;

import static org.hamcrest.MatcherAssert.assertThat;

import nz.co.zero.page.Dashboard;
import nz.co.zero.page.Invoices;
import nz.co.zero.page.LoginPage;
import nz.co.zero.page.EditInvoice;
import nz.co.zero.page.QuoteView;
import nz.co.zero.page.Quotes;
import nz.co.zero.test.baseTest;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class InvoiceTest extends baseTest {

    LoginPage loginPage;
    WebDriver driver;

    @BeforeMethod
    public void beforeMethod() {
        driver = getDriver();
        loginPage = new LoginPage(driver);
        loginPage.login();
        Dashboard dashboard = new Dashboard(driver);
        dashboard.menuBar.clickMenuItem("Business -> Quotes");
    }

    @Test(testName = "Create Draft Invoice",
            description = "As a User,\n" +
                    "In order to manage my business successfully,\n" +
                    "I want to create a draft Invoice from an existing accepted Quote")
    public void createDraftInvoice() {
        given("User navigates to Quotes table");
        Quotes quotes = new Quotes(driver);
        when("user selects the first available quote");
        quotes.quotesTable.selectRow(0);
        QuoteView quoteView = new QuoteView(driver);
        and("creates invoice and saves it");
        quoteView.createInvoice.click();
        quoteView = new QuoteView(driver);
        quoteView.popup.clickPopupButton("Create");
        EditInvoice editInvoice = new EditInvoice(driver);
        editInvoice.save.click();
        then("draft invoice is created successfully");
        Invoices invoices = new Invoices(driver);
        assertThat("Invoice not created successfully", invoices.message.getText().contains("Draft Invoice Saved"));
    }
}
