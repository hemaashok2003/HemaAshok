package nz.co.zero.page;

import static org.awaitility.Awaitility.with;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Invoices extends Page {

    @FindBy(css = "div[class*='notify'] > div[class='message'] > p")
    public WebElement message;

    public Invoices(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean exists() {
        try {
            with().pollInterval(1, TimeUnit.SECONDS).
                    await().atMost(10, TimeUnit.SECONDS).until(() -> getTitle().contains("Invoices"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
