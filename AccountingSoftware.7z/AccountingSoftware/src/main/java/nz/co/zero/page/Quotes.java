package nz.co.zero.page;

import static org.awaitility.Awaitility.with;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import javafx.scene.control.Tab;
import nz.co.zero.elements.Popup;
import nz.co.zero.elements.Table;

public class Quotes extends Page {

    public Table quotesTable;

    public Quotes(WebDriver driver) {
        super(driver);
        quotesTable = new Table(driver.findElement(By.cssSelector("#quotes-grid")));
    }

    @Override
    public boolean exists() {
        try {
            with().pollInterval(1, TimeUnit.SECONDS).
                    await().atMost(10, TimeUnit.SECONDS).until(() -> getTitle().contains("Quotes"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
