package nz.co.zero.page;

import static org.awaitility.Awaitility.with;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import nz.co.zero.elements.Popup;
import nz.co.zero.elements.Table;

public class QuoteView extends Page {

    public Popup popup;

    @FindBy(css = "div[data-automationid='sales-quoteheadertoolbar-createinvoice-button']")
    public WebElement createInvoice;

    public QuoteView(WebDriver driver) {
        super(driver);
        try {
            popup = new Popup(driver.findElement(By.cssSelector("div[class*='x-popup']")));
        } catch (Exception e) {
            popup = null;
        }
    }

    @Override
    public boolean exists() {
        try {
            with().pollInterval(1, TimeUnit.SECONDS).
                    await().atMost(10, TimeUnit.SECONDS).until(() -> getTitle().contains("Quote QU-"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
