package nz.co.zero.page;

import static org.awaitility.Awaitility.with;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EditInvoice extends Page {

    @FindBy(css = "a[title='Save as draft'] > span")
    public WebElement save;

    @FindBy(css = "input[id*='InvoiceNumber']")
    public WebElement invoiceNumber;

    public EditInvoice(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean exists() {
        try {
            with().pollInterval(1, TimeUnit.SECONDS).
                    await().atMost(10, TimeUnit.SECONDS).until(() -> getTitle().contains("Edit Invoice"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
