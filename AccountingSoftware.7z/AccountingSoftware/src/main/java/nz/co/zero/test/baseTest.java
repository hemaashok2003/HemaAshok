package nz.co.zero.test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

public class baseTest {
    private static final String DATE_FORMAT = "ddMMyyyyHHmmss";
    private static volatile ExtentReports report;
    private static final String root;

    static {
        root = "target/report_" + new SimpleDateFormat(DATE_FORMAT).format(new Date());
        File dir = new File(root);
        dir.mkdir();
    }

    private WebDriver driver;
    private String testName;
    private String testDescription;
    private ExtentTest extentTest;

    public static ExtentReports getReport() {
        return report;
    }

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() {
        report = new ExtentReports();
        report.attachReporter(new ExtentHtmlReporter(root + "/" + "report.html"));
    }

    @BeforeClass
    public void beforeClass() {
    }

    @BeforeMethod(alwaysRun = true)
    public void before(Method method) {
        setTestName(method.getAnnotation(org.testng.annotations.Test.class).testName().isEmpty() ?
                method.getName() :
                method.getAnnotation(org.testng.annotations.Test.class).testName()
        );

        setTestDescription(method.getAnnotation(org.testng.annotations.Test.class).description().isEmpty() ?
                "" : "<b>Scenario: </b>" + method.getAnnotation(org.testng.annotations.Test.class).description());

        setExtentTest(getReport().createTest(getTestName(), getTestDescription()));
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }

    @AfterMethod(alwaysRun = true)
    public void cleanup(ITestResult result) {
        if (result.getStatus() == ITestResult.SUCCESS) {
            extentTest.pass(testName + " passed");
        } else {
            extentTest.fail(testName + " failed" + "\n" + result.getThrowable());
            try {
                extentTest.addScreenCaptureFromPath(takeScreenshot());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (driver != null) {
            driver.close();
            driver.quit();
            driver = null;
        }
    }

    @AfterSuite(alwaysRun = true)
    public void cleanupSuite() {
        report.flush();
    }

    protected String takeScreenshot() throws IOException {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File file = new File(root + "/" + testName + "_failure.jpg");
        FileUtils.copyFile(scrFile, file);
        return file.getName();
    }

    public void setExtentTest(ExtentTest extentTest) {
        this.extentTest = extentTest;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public String getTestDescription() {
        return testDescription;
    }

    public void setTestDescription(String testDescription) {
        this.testDescription = testDescription;
    }

    public void given(String info) {
        extentTest.info("Given " + info);
    }

    public void when(String info) {
        extentTest.info("When " + info);
    }

    public void then(String info) {
        extentTest.info("Then " + info);
    }

    public void and(String info) {
        extentTest.info("And " + info);
    }

    public WebDriver getDriver() {
        return driver;
    }
}