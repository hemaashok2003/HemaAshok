package nz.co.zero.page;

import nz.co.zero.elements.MenuBar;
import nz.co.zero.elements.Popup;
import nz.co.zero.elements.Table;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public abstract class Page {

    protected WebDriver driver;
    public MenuBar menuBar;

    public Page(WebDriver driver) {
        this.driver = driver;
        exists();
        PageFactory.initElements(driver, this);
        menuBar = new MenuBar(driver);
    }

    public abstract boolean exists();

    public String getTitle() {
        return driver.getTitle();
    }
}
