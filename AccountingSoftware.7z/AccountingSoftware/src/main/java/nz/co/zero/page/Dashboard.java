package nz.co.zero.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;

public class Dashboard extends Page {
    public Dashboard(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean exists() {
        try {
            with().pollInterval(1, TimeUnit.SECONDS).
                    await().atMost(10, TimeUnit.SECONDS).until(() -> getTitle().contains("Dashboard"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
