package nz.co.zero.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Popup {
    private final WebElement element;

    private static final String BUTTON_CSS = "div[class*='x-popup'] > div[class*='x-toolbar'] > div > div > div[class*='x-btn']";

    public Popup(WebElement element) {
        this.element = element;
    }

    public void clickPopupButton(String buttonText) {
        List<WebElement> buttons = element.findElements(By.cssSelector(BUTTON_CSS));
        for (WebElement button : buttons) {
            if (button.getText().contains(buttonText)) {
                button.click();
            }
        }
    }
}

