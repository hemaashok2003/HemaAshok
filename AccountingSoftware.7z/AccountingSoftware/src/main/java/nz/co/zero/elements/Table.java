package nz.co.zero.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Table {

    private static final String COLUMN_LINK_CSS = "div > div[class*='x-grid-body'] > div[class*='x-grid-view'] > table > tbody > tr[class*='x-grid-data-row'] > td > div > a";
    WebElement element;

    public Table(WebElement element) {
        this.element = element;
    }

    public void selectRow(int row) {
        List<WebElement> links = element.findElements(By.cssSelector(COLUMN_LINK_CSS));
        if (links.size() > 0) links.get(row).click();
    }


}
