package nz.co.zero.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class MenuBar {
    private static final String MAINMENU_ITEM = ".xnav-tabgroup > li";
    private static final String SUBMENU_ITEM = ".xnav-verticalmenu > li";

    private final WebDriver driver;

    public MenuBar(WebDriver driver) {
        this.driver = driver;
    }

    public void clickMenuItem(String menu) {
        String[] menuItems = menu.split("->");
        for (int i = 0; i < menuItems.length; i++) {
            if(i==0) {
                List<WebElement> mainMenuItems = driver.findElements(By.cssSelector(MAINMENU_ITEM));
                for (WebElement tempMenu : mainMenuItems) {
                    if (tempMenu.getText().contains(menuItems[0].trim())) {
                        tempMenu.click();
                    }
                }
            } else {
                List<WebElement> subMenuItems = driver.findElements(By.cssSelector(SUBMENU_ITEM));
                for (WebElement tempSubMenuItem: subMenuItems)
                {
                    if (tempSubMenuItem.getText().contains(menuItems[i].trim())) {
                        tempSubMenuItem.click();
                        return;
                    }
                }
            }
        }
        throw new RuntimeException("Menu Item not found");
    }
}
