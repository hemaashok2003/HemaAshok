package nz.co.zero.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;

public class LoginPage extends Page {

    private static final String URL = "https://login.xero.com/identity/user/login?";
    private static final String user = "hema_ashok2003@hotmail.com";
    private static final String pwd = "Test@123";

    @FindBy(css = "#xl-form-email")
    public WebElement userName;

    @FindBy(css = "#xl-form-password")
    public WebElement password;

    @FindBy(css = "#xl-form-submit")
    public WebElement login;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void login() {
        driver.get(URL);
        driver.getWindowHandles().stream().forEach(handle ->
                driver.switchTo().window(handle).manage().window().maximize());

        userName.sendKeys(user);
        password.sendKeys(pwd);
        login.click();
    }

    @Override
    public boolean exists() {
        return true;
    }
}
